<?php
require_once '../Controller/RegisterController.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new RegisterController();
    $controller->register();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
</head>
<body>
    <h1>Registro de Usuario</h1>
    <p>Únete a <b>SC Motors</b> - "Liderando el camino hacia el futuro"</p>

    <form method="POST" action="">
        <label for="username">Nombre:</label>
        <input type="text" id="username" name="username" required>
        
        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        
        <label for="phone">Teléfono:</label>
        <input type="text" id="phone" name="phone" required>
        
        <label for="id_card">Cédula:</label>
        <input type="text" id="id_card" name="id_card" required>
        
        <label for="location">Dirección:</label>
        <select id="location" name="location">
            <option value="San José">San José</option>
            <option value="Limón">Limón</option>
            <option value="Puntarenas">Puntarenas</option>
            <option value="Heredia">Heredia</option>
            <option value="Guanacaste">Guanacaste</option>
            <option value="Cartago">Cartago</option>
            <option value="Alajuela">Alajuela</option>
        </select>

        <label for="role">Rol:</label>
        <select id="role" name="role">
            <option value="Administrador">Administrador</option>
            <option value="Cliente" selected>Cliente</option>
        </select>

        <button type="submit">Registrar</button>
    </form>
</body>
</html>
