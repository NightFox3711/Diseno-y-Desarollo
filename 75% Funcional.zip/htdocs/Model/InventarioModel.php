<?php
include_once 'Database.php';

// Listar todos los vehículos
function listarVehiculos() {
    $conexion = Database::AbrirBaseDatos();
    $sql = "SELECT * FROM vehicles";
    $result = $conexion->query($sql);

    $vehiculos = [];
    while ($fila = $result->fetch_assoc()) {
        $vehiculos[] = $fila;
    }

    Database::CerrarBaseDatos($conexion);
    return $vehiculos;
}

// Agregar un nuevo vehículo
function agregarVehiculo($brand, $model, $price, $status, $image_path, $headquarters) {
    $conexion = Database::AbrirBaseDatos();
    $sql = "INSERT INTO vehicles (brand, model, price, status, image_path, headquarters) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("ssdsss", $brand, $model, $price, $status, $image_path, $headquarters);
    $resultado = $stmt->execute();
    $stmt->close();
    Database::CerrarBaseDatos($conexion);
    return $resultado;
}

// Eliminar un vehículo
function eliminarVehiculo($id_vehicle) {
    $conexion = Database::AbrirBaseDatos();
    $sql = "DELETE FROM vehicles WHERE id_vehicle = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $id_vehicle);
    $resultado = $stmt->execute();
    $stmt->close();
    Database::CerrarBaseDatos($conexion);
    return $resultado;
}

// Editar el estado de un vehículo
function editarEstado($id_vehicle, $nuevo_estado) {
    $conexion = Database::AbrirBaseDatos();
    $sql = "UPDATE vehicles SET status = ? WHERE id_vehicle = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("si", $nuevo_estado, $id_vehicle);
    $resultado = $stmt->execute();
    $stmt->close();

    if ($resultado && $nuevo_estado === 'Disponible') {
        $solicitudes = obtenerSolicitudesVehiculo($id_vehicle);
        if (!empty($solicitudes)) {
            marcarNotificacionesEnviadas($id_vehicle);
        }
    }

    Database::CerrarBaseDatos($conexion);
    return $resultado;
}

// Registrar solicitud de notificación
function registrarSolicitudNotificacion($vehicleId, $userName) {
    $conexion = Database::AbrirBaseDatos();
    $sql = "INSERT INTO availability_requests (vehicle_id, user_name) VALUES (?, ?)";//No existe la tabla en la bd
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("is", $vehicleId, $userName);
    $resultado = $stmt->execute();
    $stmt->close();
    Database::CerrarBaseDatos($conexion);
    return $resultado;
}

// Obtener solicitudes pendientes
function obtenerSolicitudesVehiculo($vehicleId) {
    $conexion = Database::AbrirBaseDatos();
    $sql = "SELECT * FROM availability_requests WHERE vehicle_id = ? AND is_notified = 0";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $vehicleId);
    $stmt->execute();
    $result = $stmt->get_result();

    $solicitudes = [];
    while ($fila = $result->fetch_assoc()) {
        $solicitudes[] = $fila;
    }
    $stmt->close();
    Database::CerrarBaseDatos($conexion);
    return $solicitudes;
}

// Marcar solicitudes como notificadas
function marcarNotificacionesEnviadas($vehicleId) {
    $conexion = Database::AbrirBaseDatos();
    $sql = "UPDATE availability_requests SET is_notified = 1 WHERE vehicle_id = ? AND is_notified = 0";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $vehicleId);
    $resultado = $stmt->execute();
    $stmt->close();
    Database::CerrarBaseDatos($conexion);
    return $resultado;
}
