<?php
header("location:View/LoginView.php");
