<?php
include_once 'Database.php';



function listarSolicitudes() {
    $conexion = AbrirBaseDatos();
    
    
    $sql = "SELECT s.id, u.username AS user, s.type, s.details, s.status
            FROM support_requests s
            JOIN users u ON s.user_id = u.id";
    
   
    $resultado = mysqli_query($conexion, $sql);
    
 
    if ($resultado === false) {
        
        echo "Error en la consulta SQL: " . mysqli_error($conexion);
        return []; 
    }

    
    $solicitudes = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
    
    
    CerrarBaseDatos($conexion);
    
    return $solicitudes;
}




function crearSolicitud($user_id, $type, $details) {
    $conexion = AbrirBaseDatos();
    $user_id = $conexion->real_escape_string($user_id);
    $type = $conexion->real_escape_string($type);
    $details = $conexion->real_escape_string($details);

    $sql = "INSERT INTO support_requests (user_id, type, details) VALUES ($user_id, '$type', '$details')";
    $resultado = $conexion->query($sql);
    CerrarBaseDatos($conexion);
    return $resultado;
}


function resolverSolicitud($id) {
    $conexion = AbrirBaseDatos();
    $sql = "UPDATE support_requests SET status = 'resuelto' WHERE id = $id";
    $resultado = $conexion->query($sql);
    CerrarBaseDatos($conexion);
    return $resultado;
}
?>
