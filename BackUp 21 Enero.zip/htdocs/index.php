<?php
header("location:View/RegisterView.php");
